var config = {
    map: {
        "*": {
            "@firebase/app": "Webkul_Pwa/js/firebase-app",
            "@firebase/messaging": "Webkul_Pwa/js/firebase-messaging",
        }
    }
};
